/**
 * @author: zhangyh-k@glondon.com
 * @description:
 * @Date: 2017/10/1 下午7:56
 */
const gridData =[
    {
        shopcate:1,
        title: "地主推荐",
        image: require('../image/shouye/daiyuanquan/recommend@2x.png')
    },
    {
        shopcate:2,
        title: "早点小吃",
        image: require('../image/shouye/daiyuanquan/breakfast.png')
    },
    {
        shopcate:3,
        title: "外卖",
        image: require('../image/shouye/daiyuanquan/takeaway.png')
    },
    {
        shopcate:4,
        title: "烧烤火锅",
        image: require('../image/shouye/daiyuanquan/hotel.png')
    },
    {
        shopcate:5,
        title: "自助餐",
        image: require('../image/shouye/daiyuanquan/buffet.png')
    },
    {
        shopcate:6,
        title: "餐厅",
        image: require('../image/shouye/daiyuanquan/restaurant.png')
    },
    {
        shopcate:7,
        title: "蛋糕甜点",
        image: require('../image/shouye/daiyuanquan/dessert.png')
    },
    {
        shopcate:8,
        title: "KTV",
        image: require('../image/shouye/daiyuanquan/ktv.png')
    },
    {
        shopcate:9,
        title: "酒吧",
        image: require('../image/shouye/daiyuanquan/bar.png')
    },
    {
        shopcate:10,
        title: "网吧",
        image: require('../image/shouye/daiyuanquan/Internetcafes.png')
    },
    {
        shopcate:11,
        title: "酒店",
        image: require('../image/shouye/daiyuanquan/hotel.png')
    },
    {
        shopcate:12,
        title: "美容美发",
        image: require('../image/shouye/daiyuanquan/beautysalons.png')
    },
    {
        shopcate:13,
        title: "桑拿温泉",
        image: require('../image/shouye/daiyuanquan/spa.png')
    },
    {
        shopcate:14,
        title: "足疗按摩",
        image: require('../image/shouye/daiyuanquan/foottherapy.png')
    },
    {
        shopcate:15,
        title: "电影院",
        image: require('../image/shouye/daiyuanquan/cinema.png')
    },
    {
        shopcate:16,
        title: "汽车美容",
        image: require('../image/shouye/daiyuanquan/Carbeauty.png')
    },
    {
        shopcate:17,
        title: "汽车维修",
        image: require('../image/shouye/daiyuanquan/carrepair.png')
    },
    {
        shopcate:18,
        title: "共享汽车",
        image: require('../image/shouye/daiyuanquan/sharecar.png')
    },
    {
        shopcate:19,
        title: "汽车保险",
        image: require('../image/shouye/daiyuanquan/carinsurance.png')
    },
    {
        shopcate:20,
        title: "加油卡",
        image: require('../image/shouye/daiyuanquan/FuelCard.png')
    },
    {
        shopcate:21,
        title: "超市",
        image: require('../image/shouye/daiyuanquan/supermarket.png')
    },
    {
        shopcate:22,
        title: "药店",
        image: require('../image/shouye/daiyuanquan/pharmacy.png')
    },
    {
        shopcate:23,
        title: "共享电器",
        image: require('../image/shouye/daiyuanquan/sharedevice.png')
    },
    {
        shopcate:24,
        title: "服装",
        image: require('../image/shouye/daiyuanquan/clothing.png')
    },
    {
        shopcate:25,
        title: "运动健身",
        image: require('../image/shouye/daiyuanquan/fitness.png')
    },
    {
        shopcate:26,
        title: "家政服务",
        image: require('../image/shouye/daiyuanquan/housekeeping.png')
    },
    {
        shopcate:27,
        title: "家装家具",
        image: require('../image/shouye/daiyuanquan/furniture.png')
    },
    {
        shopcate:28,
        title: "婚庆",
        image: require('../image/shouye/daiyuanquan/wedding.png')
    },
    {
        shopcate:29,
        title: "法律咨询",
        image: require('../image/shouye/daiyuanquan/legal.png')
    },
    {
        shopcate:30,
        title: "宠物",
        image: require('../image/shouye/daiyuanquan/pet.png')
    }
];
export default gridData
