/**
 * @author: zhangyh-k@glondon.com
 * @description:
 * @Date: 2017/10/18 下午8:19
 */
export default {
    theme: '#1aa0f7',
    border: '#e0e0e0',
    background: '#f3f3f3'
}