/**
 * @author: zhangyh-k@glondon.com
 * @description:
 * @Date: 2017/10/1 上午11:30
 */
import { StyleSheet } from 'react-native';
const headerText = StyleSheet.create({

    view:{
        width:50,
    },
    view2:{
        width:80,
    },
    text:{
        fontSize:16,
        color:'white',
    }
});
export default headerText